  [![codecov](https://codecov.io/gh/LanceSports/LanceSports/branch/main/graph/badge.svg)](https://codecov.io/gh/LanceSports/LanceSports/)
  # Sports Landing Page with Slideshow

  [![codecov](https://codecov.io/gh/LanceSports/LanceSports/branch/main/graph/badge.svg)](https://codecov.io/gh/LanceSports/LanceSports/)

  This is a code bundle for Sports Landing Page with Slideshow. The original project is available at https://www.figma.com/design/4iDSNBA3egxhnACp7Zcmg9/Sports-Landing-Page-with-Slideshow.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
